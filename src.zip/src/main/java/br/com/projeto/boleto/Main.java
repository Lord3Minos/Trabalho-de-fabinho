package br.com.projeto.boleto;

import br.com.projeto.boleto.model.Boleto;
import br.com.projeto.boleto.model.DadosBoleto;
import br.com.projeto.boleto.service.GeradorBoletoService;
import br.com.projeto.boleto.service.GeradorBoletoService.Banco;
import br.com.projeto.boleto.util.BoletoPDFExporter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Scanner;

/**
 * Ponto de entrada do sistema.
 * Interface interativa via console — gera boleto no console E exporta PDF.
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);
        GeradorBoletoService service = new GeradorBoletoService();

        System.out.println("╔══════════════════════════════════╗");
        System.out.println("║   SISTEMA DE GERAÇÃO DE BOLETOS  ║");
        System.out.println("║   Padrão Builder (GoF) — FEBRABAN ║");
        System.out.println("╚══════════════════════════════════╝");
        System.out.println();

        System.out.println("Selecione o banco:");
        System.out.println("  1 — Bradesco  (código 237)");
        System.out.println("  2 — Nubank    (código 260)");
        System.out.println("  3 — Unibanco  (código 341)");
        System.out.print("Opção: ");
        int opcao = sc.nextInt();
        sc.nextLine();

        Banco banco = switch (opcao) {
            case 1 -> Banco.BRADESCO;
            case 2 -> Banco.NUBANK;
            case 3 -> Banco.UNIBANCO;
            default -> throw new IllegalArgumentException("Opção inválida.");
        };

        DadosBoleto dados = coletarDados(sc);

        // Geração via padrão Builder
        Boleto boleto = service.gerar(banco, dados);

        // Exibição no console
        boleto.imprimir();

        // Exportação para PDF
        String nomeArquivo = "boleto_" + banco.name().toLowerCase() + ".pdf";
        System.out.println("\nGerando PDF...");
        BoletoPDFExporter.exportar(boleto, nomeArquivo);
        System.out.println("Arquivo salvo em: " + System.getProperty("user.dir") + "/" + nomeArquivo);

        sc.close();
    }

    private static DadosBoleto coletarDados(Scanner sc) {
        System.out.print("Cedente (nome da empresa/pessoa): ");
        String cedente = sc.nextLine();

        System.out.print("Sacado (nome do pagador): ");
        String sacado = sc.nextLine();

        System.out.print("CPF/CNPJ do sacado: ");
        String cpfCnpj = sc.nextLine();

        System.out.print("Valor (ex: 150.75): ");
        BigDecimal valor = sc.nextBigDecimal();
        sc.nextLine();

        System.out.print("Data de vencimento (AAAA-MM-DD): ");
        LocalDate vencimento = LocalDate.parse(sc.nextLine());

        System.out.print("Nosso Número (até 8 dígitos): ");
        String nossoNumero = sc.nextLine();

        System.out.print("Agência (3 dígitos): ");
        String agencia = sc.nextLine();

        System.out.print("Conta (até 7 dígitos): ");
        String conta = sc.nextLine();

        System.out.print("Número do documento: ");
        String numDoc = sc.nextLine();

        return new DadosBoleto(cedente, sacado, cpfCnpj, valor,
                               vencimento, nossoNumero, agencia, conta, numDoc);
    }
}