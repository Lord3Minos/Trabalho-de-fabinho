package br.com.projeto.boleto.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Produto final do padrão Builder.
 * TODOS os campos são final — objeto imutável após construção.
 * Uma vez gerado, um boleto não pode ser alterado (segurança financeira).
 */
public final class Boleto {
    private final String banco;
    private final String cedente;
    private final String sacado;
    private final BigDecimal valor;
    private final LocalDate dataVencimento;
    private final String nossoNumero;
    private final String codigoBarras;      // 44 dígitos
    private final String linhaDigitavel;    // 47 dígitos formatados
    private final String campoLivre;        // 25 dígitos

    // Construtor package-private (só os builders constroem)
    public Boleto(String banco, String cedente, String sacado, BigDecimal valor,
           LocalDate dataVencimento, String nossoNumero,
           String codigoBarras, String linhaDigitavel, String campoLivre) {
        this.banco = banco;
        this.cedente = cedente;
        this.sacado = sacado;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.nossoNumero = nossoNumero;
        this.codigoBarras = codigoBarras;
        this.linhaDigitavel = linhaDigitavel;
        this.campoLivre = campoLivre;
    }

    // Apenas getters — NENHUM setter
    public String getCodigoBarras() { return codigoBarras; }
    public String getLinhaDigitavel() { return linhaDigitavel; }
    public String getBanco() { return banco; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataVencimento() { return dataVencimento; }
    public String getCedente() { return cedente; }
    public String getSacado() { return sacado; }
    public String getNossoNumero() { return nossoNumero; }
    public String getCampoLivre() { return campoLivre; }

    /**
     * Impressão formatada do boleto no console.
     */
    public void imprimir() {
        System.out.println("=".repeat(60));
        System.out.println("BOLETO BANCÁRIO — " + banco.toUpperCase());
        System.out.println("=".repeat(60));
        System.out.printf("Cedente       : %s%n", cedente);
        System.out.printf("Sacado        : %s%n", sacado);
        System.out.printf("Valor         : R$ %,.2f%n", valor);
        System.out.printf("Vencimento    : %s%n",
            dataVencimento.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.printf("Nosso Número  : %s%n", nossoNumero);
        System.out.println("-".repeat(60));
        System.out.printf("Linha Digitável: %s%n", linhaDigitavel);
        System.out.printf("Código Barras  : %s%n", codigoBarras);
        System.out.println("=".repeat(60));
    }

    @Override
    public String toString() {
        return String.format("Boleto[banco=%s, valor=R$%.2f, vencimento=%s, linhaDigitavel=%s]",
            banco, valor, dataVencimento, linhaDigitavel);
    }
}
