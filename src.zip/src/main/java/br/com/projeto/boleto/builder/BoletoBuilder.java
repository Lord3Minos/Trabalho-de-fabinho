package br.com.projeto.boleto.builder;

import br.com.projeto.boleto.model.Boleto;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Interface Builder — define o contrato fluente de construção.
 */
public interface BoletoBuilder {
    BoletoBuilder comCedente(String cedente);
    BoletoBuilder comSacado(String sacado, String cpfCnpj);
    BoletoBuilder comValor(BigDecimal valor);
    BoletoBuilder comDataVencimento(LocalDate vencimento);
    BoletoBuilder comNossoNumero(String nossoNumero);
    BoletoBuilder comAgencia(String agencia);
    BoletoBuilder comConta(String conta);
    BoletoBuilder comNumeroDocumento(String numeroDocumento);

    Boleto build();
}
