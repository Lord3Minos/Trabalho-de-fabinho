package br.com.projeto.boleto.director;

import br.com.projeto.boleto.builder.BoletoBuilder;
import br.com.projeto.boleto.model.Boleto;
import br.com.projeto.boleto.model.DadosBoleto;

/**
 * Director — orquestra a sequência de chamadas ao Builder.
 */
public class BoletoDirector {

    public Boleto construirBoleto(BoletoBuilder builder, DadosBoleto dados) {
        return builder
            .comCedente(dados.getCedente())
            .comSacado(dados.getSacado(), dados.getCpfCnpjSacado())
            .comValor(dados.getValor())
            .comDataVencimento(dados.getDataVencimento())
            .comNossoNumero(dados.getNossoNumero())
            .comAgencia(dados.getAgencia())
            .comConta(dados.getConta())
            .comNumeroDocumento(dados.getNumeroDocumento())
            .build();
    }
}
