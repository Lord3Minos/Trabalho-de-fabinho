package br.com.projeto.boleto.builder;

import br.com.projeto.boleto.model.Boleto;
import br.com.projeto.boleto.util.CalculadoraFebraban;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Builder concreto para boletos do Nubank.
 * Código do banco: 260
 * Campo Livre: Convênio (6) + Nosso Número (19) = 25 dígitos
 */
public class NubankBoletoBuilder implements BoletoBuilder {

    private static final String CODIGO_BANCO = "260";
    private static final String MOEDA = "9";
    private static final String CONVENIO_PADRAO = "000001";

    private String cedente;
    private String sacado;
    private String cpfCnpj;
    private BigDecimal valor;
    private LocalDate dataVencimento;
    private String nossoNumero;
    private String agencia;
    private String conta;
    private String numeroDocumento;

    @Override
    public BoletoBuilder comCedente(String cedente) {
        this.cedente = cedente;
        return this;
    }

    @Override
    public BoletoBuilder comSacado(String sacado, String cpfCnpj) {
        this.sacado = sacado;
        this.cpfCnpj = cpfCnpj;
        return this;
    }

    @Override
    public BoletoBuilder comValor(BigDecimal valor) {
        this.valor = valor;
        return this;
    }

    @Override
    public BoletoBuilder comDataVencimento(LocalDate vencimento) {
        this.dataVencimento = vencimento;
        return this;
    }

    @Override
    public BoletoBuilder comNossoNumero(String nossoNumero) {
        this.nossoNumero = String.format("%019d", Long.parseLong(nossoNumero));
        return this;
    }

    @Override
    public BoletoBuilder comAgencia(String agencia) {
        this.agencia = agencia;
        return this;
    }

    @Override
    public BoletoBuilder comConta(String conta) {
        this.conta = conta;
        return this;
    }

    @Override
    public BoletoBuilder comNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
        return this;
    }

    @Override
    public Boleto build() {
        validarCamposObrigatorios();

        // Passo 1: Campo Livre Nubank (25 dígitos)
        String campoLivre = CONVENIO_PADRAO + nossoNumero;

        // Passo 2: Código de barras sem DV
        String fatorVencimento = CalculadoraFebraban.calcularFatorVencimento(dataVencimento);
        String valorFormatado = CalculadoraFebraban.formatarValor(valor);
        String codigoSemDV = CODIGO_BANCO + MOEDA + fatorVencimento + valorFormatado + campoLivre;

        // Passo 3: DV Geral
        int dvGeral = CalculadoraFebraban.calcularModulo11(codigoSemDV);

        // Passo 4: Código de barras final
        String codigoBarras = CODIGO_BANCO + MOEDA + dvGeral + fatorVencimento + valorFormatado + campoLivre;

        // Passo 5: Linha Digitável
        String bloco1Base = CODIGO_BANCO + MOEDA + campoLivre.substring(0, 5);
        String bloco1 = bloco1Base + CalculadoraFebraban.calcularModulo10(bloco1Base);

        String bloco2Base = campoLivre.substring(5, 15);
        String bloco2 = bloco2Base + CalculadoraFebraban.calcularModulo10(bloco2Base);

        String bloco3Base = campoLivre.substring(15, 25);
        String bloco3 = bloco3Base + CalculadoraFebraban.calcularModulo10(bloco3Base);

        String linhaDigitavel = CalculadoraFebraban.formatarLinhaDigitavel(
            bloco1, bloco2, bloco3, String.valueOf(dvGeral), fatorVencimento + valorFormatado
        );

        return new Boleto("Nubank", cedente, sacado, valor, dataVencimento, nossoNumero,
                          codigoBarras, linhaDigitavel, campoLivre);
    }

    private void validarCamposObrigatorios() {
        if (cedente == null || sacado == null || valor == null || dataVencimento == null
            || nossoNumero == null) {
            throw new IllegalStateException("Campos obrigatórios ausentes.");
        }
        if (valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valor deve ser maior que zero.");
        }
    }
}
