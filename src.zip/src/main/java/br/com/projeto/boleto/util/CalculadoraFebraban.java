package br.com.projeto.boleto.util;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Classe utilitária com os algoritmos oficiais FEBRABAN.
 * Todos os métodos são static — sem estado.
 * ISOLADA para facilitar auditoria e testes unitários.
 */
public class CalculadoraFebraban {

    private static final LocalDate DATA_BASE_FEBRABAN = LocalDate.of(1997, 10, 7);

    /**
     * Calcula o Dígito Verificador pelo Módulo 10.
     * Usado nos blocos 1, 2 e 3 da Linha Digitável.
     */
    public static int calcularModulo10(String numero) {
        int soma = 0;
        int peso = 2;
        for (int i = numero.length() - 1; i >= 0; i--) {
            int resultado = Character.getNumericValue(numero.charAt(i)) * peso;
            if (resultado >= 10) {
                resultado = (resultado / 10) + (resultado % 10);
            }
            soma += resultado;
            peso = (peso == 2) ? 1 : 2;
        }
        int resto = soma % 10;
        return (resto == 0) ? 0 : (10 - resto);
    }

    /**
     * Calcula o Dígito Verificador Geral pelo Módulo 11.
     * Usado na posição 5 do Código de Barras.
     * REGRA CRÍTICA: se resto == 0 OU resto == 1, DV = 1
     */
    public static int calcularModulo11(String numero) {
        int soma = 0;
        int peso = 2;
        for (int i = numero.length() - 1; i >= 0; i--) {
            soma += Character.getNumericValue(numero.charAt(i)) * peso;
            peso = (peso == 9) ? 2 : peso + 1;
        }
        int resto = soma % 11;
        if (resto == 0 || resto == 1) {
            return 1;
        }
        return 11 - resto;
    }

    /**
     * Calcula o Fator de Vencimento (número de dias desde 07/10/1997).
     */
    public static String calcularFatorVencimento(LocalDate dataVencimento) {
        long dias = ChronoUnit.DAYS.between(DATA_BASE_FEBRABAN, dataVencimento);
        return String.format("%04d", dias);
    }

    /**
     * Formata o valor para 10 dígitos sem separador decimal.
     */
    public static String formatarValor(java.math.BigDecimal valor) {
        String valorStr = valor.multiply(new java.math.BigDecimal("100"))
                               .toBigInteger()
                               .toString();
        return String.format("%010d", Long.parseLong(valorStr));
    }

    /**
     * Formata a Linha Digitável com pontos e espaços conforme FEBRABAN.
     */
    public static String formatarLinhaDigitavel(String bloco1, String bloco2,
                                                 String bloco3, String dvGeral,
                                                 String fatorValor) {
        return String.format("%s %s %s %s %s",
            bloco1.substring(0, 5) + "." + bloco1.substring(5),
            bloco2.substring(0, 5) + "." + bloco2.substring(5),
            bloco3.substring(0, 5) + "." + bloco3.substring(5),
            dvGeral,
            fatorValor);
    }
}
