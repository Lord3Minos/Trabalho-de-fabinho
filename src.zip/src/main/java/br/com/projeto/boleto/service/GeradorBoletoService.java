package br.com.projeto.boleto.service;

import br.com.projeto.boleto.builder.*;
import br.com.projeto.boleto.director.BoletoDirector;
import br.com.projeto.boleto.model.Boleto;
import br.com.projeto.boleto.model.DadosBoleto;

/**
 * Fachada (Facade) que o cliente usa.
 */
public class GeradorBoletoService {

    private final BoletoDirector director = new BoletoDirector();

    public enum Banco { BRADESCO, NUBANK, UNIBANCO }

    public Boleto gerar(Banco banco, DadosBoleto dados) {
        BoletoBuilder builder = switch (banco) {
            case BRADESCO -> new BradescoBoletoBuilder();
            case NUBANK   -> new NubankBoletoBuilder();
            case UNIBANCO -> new UnibancoBoletoBuilder();
        };
        return director.construirBoleto(builder, dados);
    }
}
