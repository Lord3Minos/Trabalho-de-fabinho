package br.com.projeto.boleto.util;

import br.com.projeto.boleto.model.Boleto;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

/**
 * Exportador de Boleto para PDF com layout profissional (padrão FEBRABAN).
 *
 * Layout em 2 seções:
 *   1. Recibo do Pagador  (topo — menor)
 *   2. Ficha de Compensação (principal — maior)
 *
 * Biblioteca: OpenPDF (com.lowagie.text) — fork open-source do iText 4
 * Uso: BoletoPDFExporter.exportar(boleto, "boleto_bradesco.pdf");
 */
public class BoletoPDFExporter {

    // ── Paleta de cores ──────────────────────────────────────────────
    private static final Color COR_FAIXA_BANCO   = new Color(45, 45, 45);   // cinza escuro
    private static final Color COR_FAIXA_SECAO   = new Color(230, 230, 230); // cinza claro
    private static final Color COR_BORDA         = new Color(160, 160, 160);
    private static final Color COR_LABEL         = new Color(100, 100, 100);
    private static final Color COR_TEXTO         = new Color(20, 20, 20);
    private static final Color COR_LINHA_DIGITAL = new Color(0, 60, 120);    // azul escuro

    // ── Fontes ───────────────────────────────────────────────────────
    private static final Font FONTE_BANCO_TITULO  = new Font(Font.HELVETICA, 13f, Font.BOLD,   Color.WHITE);
    private static final Font FONTE_SECAO         = new Font(Font.HELVETICA,  8f, Font.BOLD,   COR_FAIXA_BANCO);
    private static final Font FONTE_LABEL         = new Font(Font.HELVETICA,  7f, Font.NORMAL, COR_LABEL);
    private static final Font FONTE_VALOR         = new Font(Font.HELVETICA, 10f, Font.BOLD,   COR_TEXTO);
    private static final Font FONTE_VALOR_NORMAL  = new Font(Font.HELVETICA,  9f, Font.NORMAL, COR_TEXTO);
    private static final Font FONTE_LINHA_DIG     = new Font(Font.HELVETICA, 11f, Font.BOLD,   COR_LINHA_DIGITAL);
    private static final Font FONTE_COD_BARRAS    = new Font(Font.HELVETICA,  8f, Font.NORMAL, COR_TEXTO);

    // ── Formatadores ─────────────────────────────────────────────────
    private static final DateTimeFormatter FMT_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    /**
     * Gera o PDF do boleto e salva no caminho especificado.
     *
     * @param boleto  objeto Boleto construído pelo padrão Builder
     * @param caminho caminho completo do arquivo de saída (ex: "boleto.pdf")
     */
    public static void exportar(Boleto boleto, String caminho) {
        // Página A4, margens compactas para boleto
        Document doc = new Document(PageSize.A4, 30f, 30f, 30f, 30f);

        try {
            PdfWriter.getInstance(doc, new FileOutputStream(caminho));
            doc.open();

            // ── 1. Faixa de identificação do banco ─────────────────
            doc.add(criarFaixaBanco(boleto.getBanco()));
            doc.add(Chunk.NEWLINE);

            // ── 2. RECIBO DO PAGADOR ────────────────────────────────
            doc.add(criarCabecalhoSecao("RECIBO DO PAGADOR"));
            doc.add(criarLinhaSimples(boleto, true));
            doc.add(Chunk.NEWLINE);

            // ── 3. Linha de corte ───────────────────────────────────
            doc.add(criarLinhaCortePontilhada());
            doc.add(Chunk.NEWLINE);

            // ── 4. FICHA DE COMPENSAÇÃO ─────────────────────────────
            doc.add(criarCabecalhoSecao("FICHA DE COMPENSAÇÃO"));
            doc.add(criarCabecalhoBoleto(boleto));
            doc.add(criarDadosPrincipais(boleto));
            doc.add(criarDadosComplementares(boleto));
            doc.add(Chunk.NEWLINE);

            // ── 5. Linha Digitável em destaque ──────────────────────
            doc.add(criarCampoLinhaDigitavel(boleto));
            doc.add(Chunk.NEWLINE);

            // ── 6. Código de barras (representação numérica) ─────────
            doc.add(criarCampoCodigoBarras(boleto));

            doc.close();
            System.out.println("✓ PDF gerado com sucesso: " + caminho);

        } catch (DocumentException | IOException e) {
            System.err.println("✗ Erro ao gerar PDF: " + e.getMessage());
            throw new RuntimeException("Falha na exportação do boleto para PDF", e);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // COMPONENTES VISUAIS
    // ════════════════════════════════════════════════════════════════

    /** Faixa escura no topo com nome do banco */
    private static PdfPTable criarFaixaBanco(String nomeBanco) throws DocumentException {
        PdfPTable tabela = new PdfPTable(1);
        tabela.setWidthPercentage(100f);

        PdfPCell celula = new PdfPCell(new Phrase("BANCO " + nomeBanco.toUpperCase()
            + "   |   BOLETO BANCÁRIO", FONTE_BANCO_TITULO));
        celula.setBackgroundColor(COR_FAIXA_BANCO);
        celula.setPadding(10f);
        celula.setBorder(Rectangle.NO_BORDER);
        tabela.addCell(celula);

        return tabela;
    }

    /** Faixa cinza claro indicando a seção (Recibo / Ficha) */
    private static PdfPTable criarCabecalhoSecao(String titulo) throws DocumentException {
        PdfPTable tabela = new PdfPTable(1);
        tabela.setWidthPercentage(100f);

        PdfPCell celula = new PdfPCell(new Phrase(titulo, FONTE_SECAO));
        celula.setBackgroundColor(COR_FAIXA_SECAO);
        celula.setPadding(5f);
        celula.setBorderColor(COR_BORDA);
        tabela.addCell(celula);

        return tabela;
    }

    /**
     * Linha resumida para o Recibo do Pagador
     * (cedente | valor | vencimento | nosso número)
     */
    private static PdfPTable criarLinhaSimples(Boleto boleto, boolean recibo)
            throws DocumentException {

        PdfPTable tabela = new PdfPTable(new float[]{4f, 2f, 2f, 2f});
        tabela.setWidthPercentage(100f);

        tabela.addCell(campo("Beneficiário (Cedente)", boleto.getCedente(), true));
        tabela.addCell(campo("Valor do Documento",
            String.format("R$ %,.2f", boleto.getValor()), true));
        tabela.addCell(campo("Vencimento",
            boleto.getDataVencimento().format(FMT_DATA), true));
        tabela.addCell(campo("Nosso Número", boleto.getNossoNumero(), true));

        return tabela;
    }

    /** Linha pontilhada de corte */
    private static PdfPTable criarLinhaCortePontilhada() throws DocumentException {
        PdfPTable tabela = new PdfPTable(1);
        tabela.setWidthPercentage(100f);

        PdfPCell celula = new PdfPCell(new Phrase(
            "✂ ─────────────────────────────────── CORTE AQUI ────────────────────────────────────── ✂",
            new Font(Font.HELVETICA, 7f, Font.NORMAL, COR_LABEL)));
        celula.setBorder(Rectangle.NO_BORDER);
        celula.setHorizontalAlignment(Element.ALIGN_CENTER);
        celula.setPaddingTop(4f);
        celula.setPaddingBottom(4f);
        tabela.addCell(celula);

        return tabela;
    }

    /**
     * Cabeçalho da ficha de compensação:
     * [Banco | Código] [Linha Digitável pequena]
     */
    private static PdfPTable criarCabecalhoBoleto(Boleto boleto) throws DocumentException {
        PdfPTable tabela = new PdfPTable(new float[]{3f, 7f});
        tabela.setWidthPercentage(100f);

        // Célula: banco + código FEBRABAN
        String codigoBanco = switch (boleto.getBanco().toUpperCase()) {
            case "BRADESCO" -> "237-2";
            case "NUBANK"   -> "260-3";
            default         -> "341-7"; // Unibanco/Itaú
        };
        PdfPCell bancoCelula = new PdfPCell();
        bancoCelula.addElement(new Phrase(boleto.getBanco().toUpperCase(), FONTE_VALOR));
        bancoCelula.addElement(new Phrase("Código: " + codigoBanco, FONTE_LABEL));
        bancoCelula.setBorderColor(COR_BORDA);
        bancoCelula.setPadding(6f);
        tabela.addCell(bancoCelula);

        // Célula: linha digitável no cabeçalho
        PdfPCell ldCelula = new PdfPCell(
            new Phrase(boleto.getLinhaDigitavel(),
                new Font(Font.HELVETICA, 10f, Font.BOLD, COR_LINHA_DIGITAL)));
        ldCelula.setBorderColor(COR_BORDA);
        ldCelula.setPadding(6f);
        ldCelula.setHorizontalAlignment(Element.ALIGN_RIGHT);
        ldCelula.setVerticalAlignment(Element.ALIGN_MIDDLE);
        tabela.addCell(ldCelula);

        return tabela;
    }

    /**
     * Faixa de dados principais:
     * Cedente | Sacado | Valor | Vencimento
     */
    private static PdfPTable criarDadosPrincipais(Boleto boleto) throws DocumentException {
        PdfPTable tabela = new PdfPTable(new float[]{5f, 5f});
        tabela.setWidthPercentage(100f);

        tabela.addCell(campo("Beneficiário (Cedente)", boleto.getCedente(), false));
        tabela.addCell(campo("Pagador (Sacado)",       boleto.getSacado(), false));

        return tabela;
    }

    /**
     * Segunda faixa: nosso número | agência/conta | valor | vencimento
     */
    private static PdfPTable criarDadosComplementares(Boleto boleto) throws DocumentException {
        PdfPTable tabela = new PdfPTable(new float[]{3f, 3f, 2f, 2f});
        tabela.setWidthPercentage(100f);

        tabela.addCell(campo("Nosso Número",    boleto.getNossoNumero(), false));
        tabela.addCell(campo("Campo Livre",     boleto.getCampoLivre(),  false));
        tabela.addCell(campo("Vencimento",
            boleto.getDataVencimento().format(FMT_DATA), false));
        tabela.addCell(campo("(=) Valor Cobrado",
            String.format("R$ %,.2f", boleto.getValor()), false));

        return tabela;
    }

    /**
     * Linha Digitável em destaque (caixa azul destacada)
     */
    private static PdfPTable criarCampoLinhaDigitavel(Boleto boleto) throws DocumentException {
        PdfPTable tabela = new PdfPTable(1);
        tabela.setWidthPercentage(100f);

        // Label
        PdfPCell labelCell = new PdfPCell(new Phrase("LINHA DIGITÁVEL", FONTE_LABEL));
        labelCell.setBorder(Rectangle.LEFT | Rectangle.TOP | Rectangle.RIGHT);
        labelCell.setBorderColor(COR_BORDA);
        labelCell.setPadding(5f);
        labelCell.setPaddingBottom(0f);
        tabela.addCell(labelCell);

        // Valor destacado
        PdfPCell valorCell = new PdfPCell(new Phrase(boleto.getLinhaDigitavel(), FONTE_LINHA_DIG));
        valorCell.setBorder(Rectangle.LEFT | Rectangle.BOTTOM | Rectangle.RIGHT);
        valorCell.setBorderColor(COR_BORDA);
        valorCell.setPadding(8f);
        valorCell.setPaddingTop(4f);
        tabela.addCell(valorCell);

        return tabela;
    }

    /**
     * Código de barras (representação numérica dos 44 dígitos)
     * Nota: para barras visuais reais seria necessária fonte de barcode (ex: Code128).
     * Para fins acadêmicos, exibimos o número formatado com espaçamento.
     */
    private static PdfPTable criarCampoCodigoBarras(Boleto boleto) throws DocumentException {
        PdfPTable tabela = new PdfPTable(1);
        tabela.setWidthPercentage(100f);

        PdfPCell labelCell = new PdfPCell(new Phrase("CÓDIGO DE BARRAS (44 dígitos — FEBRABAN)", FONTE_LABEL));
        labelCell.setBorder(Rectangle.LEFT | Rectangle.TOP | Rectangle.RIGHT);
        labelCell.setBorderColor(COR_BORDA);
        labelCell.setPadding(5f);
        labelCell.setPaddingBottom(0f);
        tabela.addCell(labelCell);

        // Código formatado em grupos para facilitar leitura
        String cb = boleto.getCodigoBarras();
        String cbFormatado = cb.substring(0,3)  + " " + cb.substring(3,4)  + " "
                           + cb.substring(4,5)  + " " + cb.substring(5,9)  + " "
                           + cb.substring(9,19) + "   " + cb.substring(19);
        PdfPCell valorCell = new PdfPCell(new Phrase(cbFormatado, FONTE_COD_BARRAS));
        valorCell.setBorder(Rectangle.LEFT | Rectangle.BOTTOM | Rectangle.RIGHT);
        valorCell.setBorderColor(COR_BORDA);
        valorCell.setPadding(8f);
        valorCell.setPaddingTop(4f);
        tabela.addCell(valorCell);

        return tabela;
    }

    // ════════════════════════════════════════════════════════════════
    // HELPER: cria uma célula com label pequeno + valor em destaque
    // ════════════════════════════════════════════════════════════════

    private static PdfPCell campo(String label, String valor, boolean compacto) {
        PdfPCell celula = new PdfPCell();
        celula.addElement(new Phrase(label, FONTE_LABEL));
        celula.addElement(new Phrase(valor != null ? valor : "", compacto ? FONTE_VALOR_NORMAL : FONTE_VALOR));
        celula.setBorderColor(COR_BORDA);
        celula.setPadding(compacto ? 4f : 6f);
        return celula;
    }
}