package br.com.projeto.boleto.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Data Transfer Object com os dados de entrada do usuário.
 * Não realiza nenhum cálculo — apenas transporta dados.
 */
public class DadosBoleto {
    private String cedente;
    private String sacado;
    private String cpfCnpjSacado;
    private BigDecimal valor;
    private LocalDate dataVencimento;
    private String nossoNumero;
    private String agencia;
    private String conta;
    private String numeroDocumento;

    public DadosBoleto(String cedente, String sacado, String cpfCnpjSacado, BigDecimal valor,
                       LocalDate dataVencimento, String nossoNumero, String agencia,
                       String conta, String numeroDocumento) {
        this.cedente = cedente;
        this.sacado = sacado;
        this.cpfCnpjSacado = cpfCnpjSacado;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.nossoNumero = nossoNumero;
        this.agencia = agencia;
        this.conta = conta;
        this.numeroDocumento = numeroDocumento;
    }

    public String getCedente() { return cedente; }
    public String getSacado() { return sacado; }
    public String getCpfCnpjSacado() { return cpfCnpjSacado; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataVencimento() { return dataVencimento; }
    public String getNossoNumero() { return nossoNumero; }
    public String getAgencia() { return agencia; }
    public String getConta() { return conta; }
    public String getNumeroDocumento() { return numeroDocumento; }
}
